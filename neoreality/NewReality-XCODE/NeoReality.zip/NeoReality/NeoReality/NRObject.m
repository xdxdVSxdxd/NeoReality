//
//  NRObject.m
//  NeoReality
//
//  Created by salvatore iaconesi on 8/6/11.
//  Copyright 2011 AOS. All rights reserved.
//

#import "NRObject.h"


@implementation NRObject


@synthesize titolo, lat, lon, altitude, idImage, imageUrl, identifier;


-(void) updateView
{
    
    /*
	[titleLabel setText:titolo];
	
	NSData *imageData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:self.imageUrl]];
	
	UIImage *imga = [[UIImage alloc] initWithData:imageData]; 
	
	[img setImage:imga];
	*/
    
    
}

- (void)dealloc {
	[titolo release];
	[idImage release];
	[imageUrl release];
	[identifier release];
    [super dealloc];
}

@end
