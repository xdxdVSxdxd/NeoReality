//
//  NRCoordinate.h
//  NeoReality
//
//  Created by salvatore iaconesi on 8/7/11.
//  Copyright 2011 AOS. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NRCoordinate : NSObject {
    
    float lat;
    float lon;
    
}
@property (nonatomic) float lat;
@property (nonatomic) float lon;
@end
