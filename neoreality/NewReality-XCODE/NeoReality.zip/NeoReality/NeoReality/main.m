//
//  main.m
//  NeoReality
//
//  Created by salvatore iaconesi on 8/5/11.
//  Copyright AOS 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"NeoRealityAppDelegate");
    [pool release];
    return retVal;
}
