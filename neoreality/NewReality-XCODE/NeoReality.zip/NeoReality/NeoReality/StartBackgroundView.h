//
//  StartBackgroundView.h
//  NeoReality
//
//  Created by salvatore iaconesi on 5/15/11.
//  Copyright 2011 AOS. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface StartBackgroundView : UIView {

}

@end
