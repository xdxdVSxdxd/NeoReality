//
//  StartBackgroundView.m
//  NeoReality
//
//  Created by salvatore iaconesi on 5/15/11.
//  Copyright 2011 AOS. All rights reserved.
//

#import "StartBackgroundView.h"


@implementation StartBackgroundView


- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
		
		[self setBackgroundColor:[UIColor clearColor]];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)dealloc {
    [super dealloc];
}


@end
