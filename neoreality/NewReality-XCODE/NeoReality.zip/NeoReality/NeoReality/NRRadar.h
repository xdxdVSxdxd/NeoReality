//
//  NRRadar.h
//  NeoReality
//
//  Created by salvatore iaconesi on 8/7/11.
//  Copyright 2011 AOS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "CCNode.h"
#import "NRCoordinate.h"

@interface NRRadar : CCNode {
 
    float currentLat;
    float currentLon;
    float currentHeading;
    
    CCSprite *radardish;
    
    NSMutableArray *elements;
    
    int isUpdating;
    
}

-(void) updateLat: (float) lat Lon: (float) lon;
-(void) updateHeading: (float) heading;
-(void) loadUpdatedElements: (NSArray *) newElements;

@end
