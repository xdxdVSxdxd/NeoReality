//
//  NRRadar.m
//  NeoReality
//
//  Created by salvatore iaconesi on 8/7/11.
//  Copyright 2011 AOS. All rights reserved.
//

#import "NRRadar.h"


@implementation NRRadar


-(id) init
{
    self = [super init];
    
    if(self){
    
        isUpdating  = 0;
    
        radardish = [CCSprite spriteWithFile:@"radardish.png"];
        [self addChild:radardish z:-1];
    
        
    }   
        
    
    return self;

}



-(void) updateLat: (float) lat Lon: (float) lon
{
    currentLat = lat;
    currentLon = lon;
}


-(void) updateHeading: (float) heading
{

    currentHeading = heading;
    
}








-(void) loadUpdatedElements: (NSArray *) newElements
{
    
    isUpdating = 1;
    
    
    if (!elements) {
		elements = [[NSMutableArray alloc] initWithCapacity:20];
	}
    
    [elements removeAllObjects];
    
    
    /*
    float maxdist = 0.0;
    
    for(int i = 0; i<[newElements count]; i++){
    
        NSDictionary *e = (NSDictionary *) [newElements objectAtIndex:i];
        float nlat = [[e objectForKey:@"lat"] floatValue];
        float nlon = [[e objectForKey:@"lon"] floatValue];
        CGFloat dx = nlat - currentLat;
        CGFloat dy = nlon - currentLon;
        float d = sqrt(dx*dx + dy*dy );
        
        
        if(d>maxdist){ maxdist = d; }
        
    } 
    */
    
    for(int i = 0; i<[newElements count]; i++){
        
        NSDictionary *e = (NSDictionary *) [newElements objectAtIndex:i];
        float nlat = -([[e objectForKey:@"lat"] floatValue] - currentLat)*1000;
        float nlon = -([[e objectForKey:@"lon"] floatValue] - currentLon)*1000;
        
        
        if(nlat<40&&nlon<40){
            NRCoordinate *p = [[NRCoordinate alloc] init];
            [p setLat: nlat];
            [p setLon:nlon];
        
        

            [elements addObject:p];
        }
        
    } 
    
	
    
    /*
    
	
	//NSArray *values = [newElements allValues];
	
	for (int i=0; i<[newElements count]; i++) {
		
		NSDictionary *e = (NSDictionary *) [newElements objectAtIndex:i];
		
		NSString *idc = (NSString *) [e objectForKey:@"id"];
		
		if(idc!=nil){
			NSObject *v = [elements objectForKey:idc];
            
			if(v!=nil){
                
				[elements removeObjectForKey:idc];
                
			}
            
			[elements setObject:e forKey:idc];
			
			if(!arViews){
				arViews = [[NSMutableDictionary alloc] initWithCapacity:100];
			}
			
            
            NRObject *temp = (NRObject *) [arViews objectForKey:idc];
            if(temp==nil){
                
                
                temp = [NRObject nodeWithName: (NSString *) idc ];
                
                temp.titolo = (NSString *) [e objectForKey:@"title"];
                temp.lat = [[e objectForKey:@"lat"] floatValue];
                temp.lon = [[e objectForKey:@"lon"] floatValue];
                temp.altitude = [[e objectForKey:@"altitude"] floatValue];
                [temp setIdentifier: (NSString *) idc];
                
                
                NSLog(@"[Loading texture from URL: %@]" ,(NSString *) CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (CFStringRef)[e objectForKey:@"content"], NULL, CFSTR(" "), kCFStringEncodingUTF8));
                
                
                CC3Texture *textu = [CC3Texture textureFromURL:     (NSString *) CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (CFStringRef)[e objectForKey:@"content"], NULL, CFSTR(" "), kCFStringEncodingUTF8)    ];
                
                NSLog(@"[OK Loaded]");
                
                [temp populateAsCenteredRectangleWithSize: CGSizeMake(10.0, 10.0)
                                          andTessellation: ccg(3, 3)
                                              withTexture: textu
                                            invertTexture: YES];
                temp.material.specularColor = kCCC4FLightGray;
                temp.location = cc3v(0.0, 0.0, 0.0);
                temp.rotation = cc3v(0.0, 0.0, 0.0);
                temp.shouldCullBackFaces = NO;	// Show the ground from below as well.
                temp.isTouchEnabled = YES;		// Allow the ground to be selected by touch events.
                [temp retainVertexLocations];		// Retain location data in main memory, even when it
                // is buffered to a GL VBO via releaseRedundantData,
                // so that it may be accessed for further calculations
                // when dropping objects on the ground.
                [self.cc3World addChild: temp];
                
                
                
            } else {
                
                
                
                
                temp.titolo = (NSString *) [e objectForKey:@"title"];
                temp.lat = [[e objectForKey:@"lat"] floatValue];
                temp.lon = [[e objectForKey:@"lon"] floatValue];
                temp.altitude = [[e objectForKey:@"altitude"] floatValue];
                [temp setIdentifier: (NSString *) idc];
                
                
                
                CC3Texture *textu = [CC3Texture textureFromURL:     (NSString *) CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (CFStringRef)[e objectForKey:@"content"], NULL, CFSTR(" "), kCFStringEncodingUTF8)    ];
                
                [temp populateAsCenteredRectangleWithSize: CGSizeMake(10.0, 10.0)
                                          andTessellation: ccg(3, 3)
                                              withTexture: textu
                                            invertTexture: YES];
                temp.material.specularColor = kCCC4FLightGray;
                temp.location = cc3v(0.0, 0.0, 0.0);
                temp.rotation = cc3v(0.0, 0.0, 0.0);
                temp.shouldCullBackFaces = NO;	// Show the ground from below as well.
                temp.isTouchEnabled = YES;		// Allow the ground to be selected by touch events.
                [temp retainVertexLocations];		// Retain location data in main memory, even when it
                // is buffered to a GL VBO via releaseRedundantData,
                // so that it may be accessed for further calculations
                // when dropping objects on the ground.
                [self.cc3World addChild: temp];
                
                
                
            }
            
            
            [arViews setObject:temp forKey:idc];
            
            
		}
		
	}

*/
    
    isUpdating = 0;
	
}






-(void) draw
{

    
    //glClear(GL_COLOR_BUFFER_BIT);
    
    self.rotation = -currentHeading;
    
    if(isUpdating==0 && elements){
        
        for(int i=0; i<[elements count]; i++){
        
            NRCoordinate *p = (NRCoordinate *) [elements objectAtIndex:i];
            ccDrawPoint(CGPointMake(-p.lon*20, -p.lat*20));
            
            
        }
        
    }
    
}

@end
