//
//  NRCCNodeController.h
//  NeoReality
//
//  Created by salvatore iaconesi on 8/7/11.
//  Copyright 2011 AOS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCNodeController.h"
#import "NRWebView.h"


@interface NRCCNodeController : CCNodeController {
    
}

@end
