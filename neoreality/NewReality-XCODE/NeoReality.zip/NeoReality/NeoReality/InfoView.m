//
//  InfoView.m
//  NeoReality
//
//  Created by salvatore iaconesi on 8/7/11.
//  Copyright 2011 AOS. All rights reserved.
//

#import "InfoView.h"


@implementation InfoView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        CGRect scr = [[UIScreen mainScreen]applicationFrame];
        
        infoImage = [[UIButton alloc] initWithFrame:scr ];
        
        
        
        if (scr.size.width>480) {
            [infoImage setImage:[UIImage imageNamed:@"infoScreen-iPad.png"] forState:UIControlStateNormal];
        } else {
            [infoImage setImage:[UIImage imageNamed:@"infoScreen-iPhone.png"] forState:UIControlStateNormal];
        }
        
        [self addSubview:infoImage];
        
        
        [infoImage addTarget:self action:@selector(doExitButton:) forControlEvents:UIControlEventTouchUpInside ];
        
        
    }
    return self;
}



-(void)doExitButton:(id)sender {
    
    
    [UIView beginAnimations:@"curldown" context:nil];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:1];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.superview cache:YES]; 
    [self removeFromSuperview];
    [UIView commitAnimations];
    
    
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc
{
    [infoImage release];
    [super dealloc];
}

@end
