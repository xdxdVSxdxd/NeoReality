//
//  ApriButtonView.h
//  NeoReality
//
//  Created by salvatore iaconesi on 4/18/11.
//  Copyright 2011 AOS. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ApriButtonView : UIView {
	UIImageView *apriIcon;
}

@end
