//
//  CloseButtonView.h
//  NeoReality
//
//  Created by salvatore iaconesi on 4/18/11.
//  Copyright 2011 AOS. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CloseButtonView : UIView {

	UIImageView *closeIcon;
}

@end
