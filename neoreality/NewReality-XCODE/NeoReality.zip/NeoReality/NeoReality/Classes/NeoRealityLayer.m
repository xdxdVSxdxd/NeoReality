//
//  NeoRealityLayer.m
//  NeoReality
//
//  Created by salvatore iaconesi on 8/5/11.
//  Copyright AOS 2011. All rights reserved.
//

#import "NeoRealityLayer.h"
#import "NeoRealityWorld.h"
#import <math.h>


@implementation NeoRealityLayer


@synthesize elements, curLocation, curHeading, arViews,radar, labelSprite;

- (void)dealloc {
    [labelSprite release];
    [refreshSprite release];
    [radar release];
    [curHeading release];
	[curLocation release];
	[elements release];
	[arViews release];
    [logoSprite release];
    [super dealloc];
}


/**
 * Template method that is invoked automatically during initialization, regardless
 * of the actual init* method that was invoked. Subclasses can override to set up their
 * 2D controls and other initial state without having to override all of the possible
 * superclass init methods.
 *
 * The default implementation does nothing. It is not necessary to invoke the
 * superclass implementation when overriding in a subclass.
 */
-(void) initializeControls {

    
    self.isTouchEnabled = YES;
    
    arViews = [[NSMutableDictionary alloc] initWithCapacity:100];
    accelerometer = [UIAccelerometer sharedAccelerometer];
    accelerometer.updateInterval = .1;
    accelerometer.delegate = self;
    
    accx = 0;
    accy = 0;
    accz = 0;
    
    isUpdatingDrawing = NO;

    CGRect screenRect = [[UIScreen mainScreen] applicationFrame];
    
    logoSprite = [CCSprite spriteWithFile:@"NRLogo.png"];
    refreshSprite = [CCSprite spriteWithFile:@"refreshIcon.png"];

    
    
    listSprite = [CCSprite spriteWithFile:@"listIcon.png"];
    
    [self addChild:listSprite];
    
    listSprite.position = ccp(screenRect.size.width/2, 60 );
    
    labelSprite = [CCLabelTTF labelWithString:@"ready..." fontName:@"Helvetica" fontSize:12];
    [self addChild:labelSprite];
    
    
    
    logoSprite.position = ccp(screenRect.size.width-35, 60 ); 
    
    
    refreshSprite.position = ccp( screenRect.size.width-35, screenRect.size.height-35 );

    [self addChild:logoSprite];
    [self addChild:refreshSprite];
    
    radar = [[NRRadar alloc] init];
    
    [self addChild:radar];
    
    radar.position = ccp(45, 75 );

    [labelSprite setAnchorPoint: ccp(0, 0.5f)];
    labelSprite.position = ccp(10,screenRect.size.height-15);
    labelSprite.color = ccc3(255,255,255);
}



-(void) registerWithTouchDispatcher
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
}




-(CGRect) rect: (CCSprite *) sprite
{
	return CGRectMake( sprite.position.x - sprite.contentSize.width*sprite.anchorPoint.x, sprite.position.y-
					  sprite.contentSize.height*sprite.anchorPoint.y,
					  sprite.contentSize.width, sprite.contentSize.height);
}


- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{

    //NSLog(@"TOUCHED IN LAYER: \n%@\n\n%@\n\n\n" , touch, event);
    
    
    CGPoint location = [touch locationInView: [touch view]];
    CGPoint converted = [[CCDirector sharedDirector] convertToGL:location];
    
    NSLog(@"touchpoint:%f,%f ; texturerect: %f,%f,%f,%f", converted.x, converted.y , [logoSprite textureRect].size.width,[logoSprite textureRect].size.height,[logoSprite textureRect].origin.x,[logoSprite textureRect].origin.y );
    
    
    
    CGPoint local = [logoSprite convertToNodeSpace:converted];
    CGRect r = [self rect:logoSprite];
    r.origin = CGPointZero;
    if( CGRectContainsPoint( r, local ) ){
    
        //NSLog(@"Toccato il logo!!!!!!");  
        NeoRealityAppDelegate *appd = (NeoRealityAppDelegate *) [[UIApplication sharedApplication] delegate];
        
        [appd openInfoScreen];
        
        
        
    }
    
    
    local = [refreshSprite convertToNodeSpace:converted];
    r = [self rect:refreshSprite];
    r.origin = CGPointZero;
    if( CGRectContainsPoint( r, local ) ){
        
        NSLog(@"Toccato il refresh!!!!!!");  
        NeoRealityAppDelegate *appd = (NeoRealityAppDelegate *) [[UIApplication sharedApplication] delegate];
        
        [appd updateContent];
        
        
        
    }
    
    
    local = [listSprite convertToNodeSpace:converted];
    r = [self rect:listSprite];
    r.origin = CGPointZero;
    if( CGRectContainsPoint( r, local ) ){
        
        NSLog(@"Toccato il list!!!!!!");  
        NeoRealityAppDelegate *appd = (NeoRealityAppDelegate *) [[UIApplication sharedApplication] delegate];
        
        //[appd updateContent];
        
        [appd openList];
        
    }
    
    
    
    return [super ccTouchBegan:touch withEvent:event];

}



- (void)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration {
	
	
	accx = (accx + acceleration.x)/2.0;
	accy = (accy + acceleration.y)/2.0;
	accz = (accz + acceleration.z)/2.0;
    
    
	
	//NSLog(@"(x,y,z)=%f,%f,%f",currAcceleration.x,currAcceleration.y,currAcceleration.z );
}






-(void) loadUpdatedElements: (NSArray *) newElements
{
    
    
    [radar loadUpdatedElements:newElements];
    
	if (!elements) {
		elements = [[NSMutableDictionary alloc] initWithCapacity:20];
	}
	
	//NSArray *values = [newElements allValues];
	
	for (int i=0; i<[newElements count]; i++) {
		
		NSDictionary *e = (NSDictionary *) [newElements objectAtIndex:i];
		
		NSString *idc = (NSString *) [e objectForKey:@"id"];
		
		if(idc!=nil){
			NSObject *v = [elements objectForKey:idc];
            
			if(v!=nil){
                
				[elements removeObjectForKey:idc];
                
			}
            
			[elements setObject:e forKey:idc];
			
			if(!arViews){
				arViews = [[NSMutableDictionary alloc] initWithCapacity:100];
			}
			
            
            NRObject *temp = (NRObject *) [arViews objectForKey:idc];
            if(temp==nil){
            
                
                //NSLog(@"Initialized object");
                
                temp = [NRObject nodeWithName: (NSString *) idc ];
                
                temp.titolo = (NSString *) [e objectForKey:@"title"];
                temp.lat = [[e objectForKey:@"lat"] floatValue];
                temp.lon = [[e objectForKey:@"lon"] floatValue];
                temp.altitude = [[e objectForKey:@"altitude"] floatValue];
                [temp setIdentifier: (NSString *) idc];
                
                
                NSLog(@"[Loading texture from URL: %@]" ,(NSString *) CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (CFStringRef)[e objectForKey:@"content"], NULL, CFSTR(" "), kCFStringEncodingUTF8));
                      
                
                CC3Texture *textu = [CC3Texture textureFromURL:     (NSString *) CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (CFStringRef)[e objectForKey:@"content"], NULL, CFSTR(" "), kCFStringEncodingUTF8)    ];
                
                NSLog(@"[OK Loaded]");
                
                [temp populateAsCenteredRectangleWithSize: CGSizeMake(10.0, 10.0)
                                            andTessellation: ccg(3, 3)
                                                withTexture: textu
                                              invertTexture: YES];
                temp.material.specularColor = kCCC4FLightGray;
                temp.location = cc3v(0.0, 0.0, 0.0);
                temp.rotation = cc3v(0.0, 0.0, 0.0);
                temp.shouldCullBackFaces = NO;	// Show the ground from below as well.
                temp.isTouchEnabled = YES;		// Allow the ground to be selected by touch events.
                [temp retainVertexLocations];		// Retain location data in main memory, even when it
                // is buffered to a GL VBO via releaseRedundantData,
                // so that it may be accessed for further calculations
                // when dropping objects on the ground.
                [self.cc3World addChild: temp];

                
            
            } else {
            
                
                
                //NSLog(@"Updated object");

                
                temp.titolo = (NSString *) [e objectForKey:@"title"];
                temp.lat = [[e objectForKey:@"lat"] floatValue];
                temp.lon = [[e objectForKey:@"lon"] floatValue];
                temp.altitude = [[e objectForKey:@"altitude"] floatValue];
                [temp setIdentifier: (NSString *) idc];
                
                
                
                CC3Texture *textu = [CC3Texture textureFromURL:     (NSString *) CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (CFStringRef)[e objectForKey:@"content"], NULL, CFSTR(" "), kCFStringEncodingUTF8)    ];
                
                [temp populateAsCenteredRectangleWithSize: CGSizeMake(10.0, 10.0)
                                          andTessellation: ccg(3, 3)
                                              withTexture: textu
                                            invertTexture: YES];
                temp.material.specularColor = kCCC4FLightGray;
                temp.location = cc3v(0.0, 0.0, 0.0);
                temp.rotation = cc3v(0.0, 0.0, 0.0);
                temp.shouldCullBackFaces = NO;	// Show the ground from below as well.
                temp.isTouchEnabled = YES;		// Allow the ground to be selected by touch events.
                [temp retainVertexLocations];		// Retain location data in main memory, even when it
                // is buffered to a GL VBO via releaseRedundantData,
                // so that it may be accessed for further calculations
                // when dropping objects on the ground.
                [self.cc3World addChild: temp];
                
                
            
            }
            
            
            [arViews setObject:temp forKey:idc];
            
            /*
			OverlayView *temp = (OverlayView *) [arViews objectForKey:idc];
			if(temp==nil){
				temp = [[OverlayView alloc] initWithTitle: [e objectForKey:@"title"]  imageId:[e objectForKey:@"id"] imageURL:[e objectForKey:@"content"] latitude:[[e objectForKey:@"lat"] floatValue] longitude:[[e objectForKey:@"lon"] floatValue] altitude:[[e objectForKey:@"altitude"] floatValue] identifier: (NSString *) idc ];
				[temp setUserInteractionEnabled:YES];
				[self addSubview:temp];
                
			} else {
				[temp setTitolo:[e objectForKey:@"title"]];
				[temp setUserInteractionEnabled:YES];
				[temp setImageUrl:[e objectForKey:@"content"]];
				[temp setLat:[[e objectForKey:@"lat"] floatValue]];
				[temp setLon:[[e objectForKey:@"lon"] floatValue]];
				[temp setAltitude:[[e objectForKey:@"altitude"] floatValue]];
				[temp setIdentifier:(NSString *) idc];
				[temp updateView];
			}
			
			[arViews setObject:temp forKey:idc];
			*/
            
		}
		
	}
	
}


-(void) updateDrawing
{
	
	
	if(!isUpdatingDrawing){
        
        //NSLog(@"Updating drawing");

		
		isUpdatingDrawing = YES;
        
		//NSLog(@"currhead:%@\ncurrLoc:%@\n\n",self.curHeading,self.curLocation);
		NSArray *keys = [arViews allKeys];
		NSObject *k;
		NRObject *v;
		CLLocation *tmpLoc;
		float lat1,lat2,lon1,lon2;
        
		//TODO FIXARE USO DI QUESTE DUE VARS
        //CGRect scrsiz = [[UIScreen mainScreen] applicationFrame];
        
        
        
		lat1 = self.curLocation.coordinate.latitude*180/M_PI;
		lon1 = self.curLocation.coordinate.longitude*180/M_PI;
        
		for(int i=0; i<[keys count]; i++){
            
			k = [keys objectAtIndex:i];
			v = (NRObject *) [arViews objectForKey:k];
            
			lat2 = v.lat*180/M_PI;
			lon2 = v.lon*180/M_PI;
            
			tmpLoc = [[CLLocation alloc] initWithLatitude:v.lat longitude:v.lon];
            
            
            float dlat = (v.lat-self.curLocation.coordinate.latitude);
            float dlon = (v.lon-self.curLocation.coordinate.longitude );
            
            float dlon2 = dlon;
            float dlat2 = dlat;
            
            if(dlat2<0){ dlat2 = -dlat2; }
            if(dlon2<0){ dlon2 = -dlon2; }
            
            float anglo = atan2f(dlon2, dlat2)*180/M_PI;

            
            if ((self.curLocation.coordinate.longitude<v.lon) && (self.curLocation.coordinate.latitude<v.lat))
            {
                anglo=360-anglo;
            }
            if((self.curLocation.coordinate.longitude>v.lon) && (self.curLocation.coordinate.latitude>v.lat)) 
            {
                anglo = 180-anglo;
            }
            if ((self.curLocation.coordinate.longitude<v.lon) && (self.curLocation.coordinate.latitude>v.lat)) {
                anglo = anglo+180;
            }
            
            v.rotation = cc3v(0,  anglo,0);
            
            v.location = cc3v( dlon*500000 , v.altitude*5 ,  -dlat*500000  );
            
            
            //NSLog(@"position of %@ [%f,%f]",v.titolo, -(v.lat-self.curLocation.coordinate.latitude) , -(v.lon-self.curLocation.coordinate.longitude ) );
            
            
			//double latDelta = (lat2 - lat1);
			double lonDelta = (lon2 - lon1);
			double yy = sin(lonDelta) * cos(lat2);
			double xx = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2)* cos(lonDelta);
			double angle = atan2(yy, xx); //not finished here yet
			double headingDeg = self.curHeading.trueHeading;
			double angleDeg = angle * 180/M_PI;
			double heading = headingDeg*M_PI/180;
			angle = fmod(angleDeg + 360, 360) * M_PI/180; //normalize to 0 to 360 (instead of -180 to 180), then convert back to radians
			angleDeg = angle * 180/M_PI;
            
            self.cc3World.activeCamera.rotation = cc3v((accz)*100.00 , -headingDeg, 0.0);
            
            //NSLog(@"[%f,%f,%f]",accx,accy,accz);
            
			//CORREGGERE!
			float distance = [self.curLocation distanceFromLocation:tmpLoc];
			//NSLog(@"distanza:%f",distance);
            
			
			double deltaangledeg = (angle-heading)*180/M_PI;
			//NSLog(@"da=%f",deltaangledeg);
			
			
			
			
			//TODO FIXARE USO DI QUESTE DUE VARS
            //float ax = sin(angle-heading) * distance;
			//float az = cos(angle-heading) * distance; //typically, z faces into the screen, but in our 2D map, it is a y-coordinate, as if you are looking from the bottom down on the world, like Google Maps
			
            
            
            
            //float ay = (accz + 2.3f )/4.6f * scrsiz.size.height; 
			//NSLog(@"ay=%f",ay);
			
            //TODO FIXARE USO DI QUESTA VAR
            //float screenX = (ax * 256) / az;
			
			
			//TODO FIXARE USO DI QUESTE DUE VARS
            //float deltaAltitude = curLocation.altitude - v.altitude;
			//float cccz = (accz)/2.3f;
			
            
            
            
            //TODO
            // USARE screenY
			//float screenY =   deltaAltitude/(200.0f*(distance+0.00001))  + scrsiz.size.height/2.0f + cccz*(scrsiz.size.height/1.0f) ; //20;//(scrsiz.size.height - 20) - (scrsiz.size.height - 20)*distance/500.0f  ;//(ay * 256) / az;
			
			//if([v.titolo isEqualToString:@"verso stazione trastevere"]){
			//	NSLog(@"[%@]->deltaA=%f",v.titolo, deltaangledeg);
			//}
			
			
			if(accy>0 || deltaangledeg>45 || deltaangledeg<0 || distance>500 ){
				
                //TODO Fix this
                //[v setHidden:YES];
			} else {
				//TODO Fix this
                //[v setHidden:NO];
				if(distance<100){
					//TODO Fix this
                    //[v setAlpha:1.0f];
				} else {
					//TODO Fix this
                    //[v setAlpha:(1.0f-(distance-50.0f)/450.0f)];
				}
				
				
				//TODO Fix this
                // al posto dello scale
				/*
                if(distance>100.0f){
					[v setTransform:CGAffineTransformIdentity];
				} else {
					float s = 3.0f - 2.0f*distance/100.0f;
					[v setTransform:CGAffineTransformScale(CGAffineTransformIdentity, s, s)];
				}
				*/
                
                
			}
            
            //TODO Fix this
            //v.frame = CGRectMake(screenX, screenY, 70,110);
            
            
		}
		
		isUpdatingDrawing = NO;
	}
	
}



 // The ccTouchMoved:withEvent: method is optional for the <CCTouchDelegateProtocol>.
 // The event dispatcher will not dispatch events for which there is no method
 // implementation. Since the touch-move events are both voluminous and seldom used,
 // the implementation of ccTouchMoved:withEvent: has been left out of the default
 // CC3Layer implementation. To receive and handle touch-move events for object
 // picking,uncomment the following method implementation. To receive touch events,
 // you must also set the isTouchEnabled property of this instance to YES.
/*
 // Handles intermediate finger-moved touch events. 
-(void) ccTouchMoved: (UITouch *)touch withEvent: (UIEvent *)event {
	[self handleTouch: touch ofType: kCCTouchMoved];
}
*/

@end
