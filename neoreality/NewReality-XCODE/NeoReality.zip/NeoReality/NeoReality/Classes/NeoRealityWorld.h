//
//  NeoRealityWorld.h
//  NeoReality
//
//  Created by salvatore iaconesi on 8/5/11.
//  Copyright AOS 2011. All rights reserved.
//


#import "CC3World.h"
#import "CC3MeshNode.h"
#import "NRObject.h"
#import "NeoRealityAppDelegate.h"

/** A sample application-specific CC3World subclass.*/
@interface NeoRealityWorld : CC3World {}

@end
