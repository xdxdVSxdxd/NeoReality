//
//  NeoRealityAppDelegate.h
//  NeoReality
//
//  Created by salvatore iaconesi on 8/5/11.
//  Copyright AOS 2011. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CCNodeController.h"
#import "CC3World.h"
#import "CC3Layer.h"
#import "NeoRealityLayer.h"
#import <CoreLocation/CoreLocation.h>
#import "ASIHTTPRequest.h"
#import "JSON.h"
#import "NRWebView.h"
#import "NRCCNodeController.h"
#import "InfoView.h"

@class NeoRealityLayer;

@interface NeoRealityAppDelegate : NSObject < CLLocationManagerDelegate,UIApplicationDelegate,UITabBarControllerDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate> {
    
	UIWindow* window;
	NRCCNodeController* viewController;
    
    
    InfoView *iview;
    
	CLLocationManager *locationManager;
	CLLocation *bestEffortAtLocation;
	CLLocation *lastUpdateDoneAtLocation;
	CLHeading *lastHeading;
	SBJsonParser *jsonParser;
	BOOL isUpdatingContent;
	UIActivityIndicatorView *loadingView;
    
    NeoRealityLayer *cc3Layer;
    
    
    NRWebView *vista;
    
}

@property (nonatomic, retain) NRWebView *vista;
@property (nonatomic,retain)InfoView *iview;

@property (nonatomic,retain) NRCCNodeController* viewController;
@property (nonatomic, retain) UIWindow* window;
@property (nonatomic, retain) CLLocationManager *locationManager;
@property (nonatomic, retain) CLLocation *bestEffortAtLocation;
@property (nonatomic, retain) CLHeading *lastHeading;
@property (nonatomic, retain) SBJsonParser *jsonParser;
@property (nonatomic, retain) UIActivityIndicatorView *loadingView;
@property (nonatomic, retain) NeoRealityLayer *cc3Layer;


-(void) updateContent;
-(void) openInfo:(NSString *) idContent;
-(void) openInfoScreen;
-(void) openList;

@end
