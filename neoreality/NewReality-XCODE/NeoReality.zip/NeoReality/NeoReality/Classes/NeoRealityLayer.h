//
//  NeoRealityLayer.h
//  NeoReality
//
//  Created by salvatore iaconesi on 8/5/11.
//  Copyright AOS 2011. All rights reserved.
//


#import "CC3Layer.h"
#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "NRObject.h"
#import "NRRadar.h"
#import "CCLabelTTF.h"
/** A sample application-specific CC3Layer subclass. */


@interface NeoRealityLayer : CC3Layer <UIAccelerometerDelegate> {

    NSMutableDictionary *elements;
	NSMutableDictionary *arViews;
	CLLocation *curLocation;
	CLHeading *curHeading;
	UIAccelerometer *accelerometer;
	double accx,accy,accz;
	BOOL isUpdatingDrawing;
    
    CCSprite *logoSprite;
    CCSprite *refreshSprite;
    CCSprite *listSprite;
    
    CCLabelTTF *labelSprite;

    NRRadar *radar;
}

@property (nonatomic,retain) NSMutableDictionary *elements;
@property (nonatomic,retain) NSMutableDictionary *arViews;
@property (nonatomic,retain) CLLocation *curLocation;
@property (nonatomic,retain) CLHeading *curHeading;
@property (nonatomic,retain) CCLabelTTF *labelSprite;
@property (nonatomic,retain) NRRadar *radar;

-(void) loadUpdatedElements: (NSArray *) newElements;

-(void) updateDrawing;

@end
