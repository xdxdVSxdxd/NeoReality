//
//  NeoRealityAppDelegate.m
//  NeoReality
//
//  Created by salvatore iaconesi on 8/5/11.
//  Copyright AOS 2011. All rights reserved.
//

#import "cocos2d.h"

#import "NeoRealityAppDelegate.h"
#import "NeoRealityLayer.h"
#import "NeoRealityWorld.h"
#import "CC3EAGLView.h"

@implementation NeoRealityAppDelegate

@synthesize iview, vista, cc3Layer, window,  locationManager, bestEffortAtLocation, lastHeading, jsonParser, loadingView, viewController;

- (void)dealloc {
    [iview release];
    [vista release];
    [cc3Layer release];
 	[loadingView release];
	[locationManager release];
	[lastHeading release];
	[bestEffortAtLocation release];
	[lastUpdateDoneAtLocation release];
	[jsonParser release];
	[[CCDirector sharedDirector] release];
	[window release];
	[viewController release];
	[super dealloc];
}


-(void) openList
{

    if(vista!=nil){
        
        
        if([vista isDescendantOfView:[viewController view]]){
            [vista removeFromSuperview];
        }
        
        [vista release];
    }
    
    vista = [[NRWebView alloc] initWithFrame: [[UIScreen mainScreen] applicationFrame]  ];
    
    NSLog(@"%@/wp-content/plugins/neoreality/getContentList.php", kHOSTBaseName);
    
    
    NSString *urlAddress = [NSString stringWithFormat:@"%@/wp-content/plugins/neoreality/getContentList.php", kHOSTBaseName];
    
    NSURL *urlo = [NSURL URLWithString:urlAddress];
    
    NSURLRequest *urq = [NSURLRequest requestWithURL:urlo];
    
    [vista loadRequest:urq];
    
    
    
    
    [UIView beginAnimations:@"curlup" context:nil];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:1];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:viewController.view cache:YES]; 
    [viewController.view addSubview:vista];
    [UIView commitAnimations];
    
    


}

-(void) openInfo:(NSString *) idContent
{
    
    if(vista!=nil){
    

        if([vista isDescendantOfView:[viewController view]]){
            [vista removeFromSuperview];
        }
    
        [vista release];
    }

    vista = [[NRWebView alloc] initWithFrame: [[UIScreen mainScreen] applicationFrame]  ];
    
    NSLog(@"%@/wp-content/plugins/neoreality/getARContent.php?id=%@", kHOSTBaseName, idContent);
    
    
    NSString *urlAddress = [NSString stringWithFormat:@"%@/wp-content/plugins/neoreality/getARContent.php?id=%@", kHOSTBaseName, idContent];
    
    NSURL *urlo = [NSURL URLWithString:urlAddress];
    
    NSURLRequest *urq = [NSURLRequest requestWithURL:urlo];
    
    [vista loadRequest:urq];
    
    
    
    
    [UIView beginAnimations:@"curlup" context:nil];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:1];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:viewController.view cache:YES]; 
    [viewController.view addSubview:vista];
    [UIView commitAnimations];
    
    


}





-(void) openInfoScreen
{
    
    if(iview!=nil){
        
        
        if([iview isDescendantOfView:[viewController view]]){
            [iview removeFromSuperview];
        }
        
        [iview release];
    }
    
    iview = [[InfoView alloc] initWithFrame: [[UIScreen mainScreen] applicationFrame]  ];
    
    [UIView beginAnimations:@"curlup" context:nil];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:1];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:viewController.view cache:YES]; 
    [viewController.view addSubview:iview];
    [UIView commitAnimations];
    
    
    
    
}




- (void) applicationDidFinishLaunching:(UIApplication*)application {
	// Init the window
	window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	
	// Try to use CADisplayLink director
	// if it fails (SDK < 3.1) use the default director
	if( ! [CCDirector setDirectorType:kCCDirectorTypeDisplayLink] )
		[CCDirector setDirectorType:kCCDirectorTypeDefault];
	
	CCDirector *director = [CCDirector sharedDirector];

	// If the rotation is going to be controlled by a UIViewController
	// then the device orientation should be "Portrait".
	[director setDeviceOrientation:kCCDeviceOrientationPortrait];

	[director setAnimationInterval:1.0/60];
	[director setDisplayFPS:NO];
	
	// Alloc & init the EAGLView
	//  1. Transparency (alpha blending), and device camera overlay requires an alpha channel,
	//     so must use RGBA8 color format. If not using device overlay or alpha blending
	//     (transparency) in any 3D or 2D graphics this can be changed to kEAGLColorFormatRGB565.
	//	2. 3D rendering requires a depth format of 16 bit.
	//  3. For highest performance, multisampling antialiasing is disabled by default.
	//     To enable multisampling antialiasing, set the multiSampling parameter to YES.
	//     You can also change the number of samples used with the numberOfSamples parameter.
	//  4. If you are using BOTH multisampling antialiasing AND node picking from touch events,
	//     use the CC3EAGLView class instead of EAGLView. When using EAGLView, multisampling
	//     antialiasing interferes with the color-testing algorithm used for touch-event node picking.
	EAGLView *glView = [CC3EAGLView viewWithFrame: [window bounds]
									  pixelFormat: kEAGLColorFormatRGBA8
									  depthFormat: GL_DEPTH_COMPONENT16_OES
							   preserveBackbuffer: NO
									   sharegroup: nil
									multiSampling: NO
								  numberOfSamples: 4];
	
	// Turn on multiple touches if needed
	[glView setMultipleTouchEnabled: YES];
	
	// attach the openglView to the director
	[director setOpenGLView:glView];
						
	// Enables High Res mode (Retina Display) on iPhone 4 and maintains low res on all other devices
//	if( ! [director enableRetinaDisplay:YES] )
//		CCLOG(@"Retina Display Not supported");
						
	
	// make the GL view a child of the main window and present it
	
    
    // disattivando la tabbar riattivare questi
    [window addSubview: glView];
	[window makeKeyAndVisible];
    
    
    
    

	// Default texture format for PNG/BMP/TIFF/JPEG/GIF images
	// It can be RGBA8888, RGBA4444, RGB5_A1, RGB565
	// You can change anytime.
	[CCTexture2D setDefaultAlphaPixelFormat:kCCTexture2DPixelFormat_RGBA8888];
	
	
	// ******** START OF COCOS3D SETUP CODE... ********
	
	// Create the customized CC3Layer that supports 3D rendering,
	// and schedule it for automatic updates
	cc3Layer = [NeoRealityLayer node];
	[cc3Layer scheduleUpdate];
	
	// Create the customized 3D world, attach it to the layer, and start it playing.
	cc3Layer.cc3World = [NeoRealityWorld world];
    
    
	ControllableCCLayer* mainLayer = cc3Layer;
	
	// The 3D layer can run either direcly in the scene, or it can run as a smaller "sub-window"
	// within any standard CCLayer. So you can have a mostly 2D window, with a smaller 3D window
	// embedded in it. To experiment with this smaller embedded 3D window, uncomment the following lines:
//	CGSize winSize = [[CCDirector sharedDirector] winSize];
//	cc3Layer.position = CGPointMake(30.0, 40.0);
//	cc3Layer.contentSize = CGSizeMake(winSize.width - 70.0, winSize.width - 40.0);
//	cc3Layer.alignContentSizeWithDeviceOrientation = YES;
//	mainLayer = [ControllableCCLayer layerWithColor: ccc4(0, 0, 0, 255)];
//	[mainLayer addChild: cc3Layer];
	
	// When it is smaller, you can even move the 3D layer around on the screen dyanmically.
	// To see this in action, uncomment the lines above as described, and also uncomment
	// the following two lines. The shouldAlwaysUpdateViewport property ensures that the
	// 3D world tracks the updated position of the 3D layer within its parent layer.
//	cc3Layer.shouldAlwaysUpdateViewport = YES;
//	[cc3Layer runAction: [CCMoveTo actionWithDuration: 10.0 position: ccp(100.0, 200.0)]];
	
	// The controller is optional. If you want to auto-rotate the view when the device orientation
	// changes, or if you want to display a device camera behind a combined 3D & 2D scene
	// (augmented reality), use a controller. Otherwise you can simply remove the following lines
	// and uncomment the lines below these lines that uses the traditional CCDirector scene startup.
	viewController = [[NRCCNodeController controller] retain];
	viewController.doesAutoRotate = NO;
    viewController.isOverlayingDeviceCamera = YES;
	[viewController runSceneOnNode: mainLayer];		// attach the layer to the controller and run a scene with it
	
    
    
    /*
     UIImageView *logo = [[UIImageView alloc] initWithImage:[[UIImage alloc] initWithContentsOfFile:@"NRLogo.png"] ];
    
    [viewController.picker.cameraOverlayView addSubview: logo];
    
    CGRect appFrame = [[UIScreen mainScreen] applicationFrame];
    
    //[viewController.view addSubview:logo];
    [logo setFrame:CGRectMake( appFrame.size.width-65 , appFrame.size.height-65 , 60  , 60)];
    */
    
    
    isUpdatingContent = NO;
	
	
    
    
    locationManager = [[CLLocationManager alloc] init];
	locationManager.delegate = self;
	locationManager.desiredAccuracy = kCLLocationAccuracyBest;
	locationManager.distanceFilter = kCLDistanceFilterNone;
	locationManager.headingFilter = kCLHeadingFilterNone;
	[locationManager startUpdatingLocation];
	[locationManager startUpdatingHeading];
    
	// If a controller is NOT used, uncomment the following standard CCDirector scene startup lines,
	// and remove the lines above that reference viewContoller.
//	CCScene *scene = [CCScene node];
//	[scene addChild: mainLayer];
//	[[CCDirector sharedDirector] runWithScene: scene];
	
}

- (void)applicationWillResignActive:(UIApplication *)application {
	[[CCDirector sharedDirector] pause];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
	[[CCDirector sharedDirector] resume];
}

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
	[[CCDirector sharedDirector] purgeCachedData];
}

-(void) applicationDidEnterBackground:(UIApplication*)application {
	[[CCDirector sharedDirector] stopAnimation];
}

-(void) applicationWillEnterForeground:(UIApplication*)application {
	[[CCDirector sharedDirector] startAnimation];
}

- (void)applicationWillTerminate:(UIApplication *)application {
	CCDirector *director = [CCDirector sharedDirector];
	
	[[director openGLView] removeFromSuperview];
	
	[viewController release];
	
	[window release];
	
	[director end];	
}

- (void)applicationSignificantTimeChange:(UIApplication *)application {
	[[CCDirector sharedDirector] setNextDeltaTimeZero:YES];
}


- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation{
	return (interfaceOrientation==UIInterfaceOrientationPortrait);
}






- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    
	self.bestEffortAtLocation = [newLocation copy];
	
    // FARE UPDATE CNTENUTI
	//[arOverlay setCurLocation:self.bestEffortAtLocation];
	//[arOverlay updateDrawing];
    [cc3Layer setCurLocation:self.bestEffortAtLocation];
    [cc3Layer updateDrawing];

	
    [cc3Layer.radar updateLat:self.bestEffortAtLocation.coordinate.latitude Lon:self.bestEffortAtLocation.coordinate.longitude ];
	
	float distance = 0;
	
	if(lastUpdateDoneAtLocation){
		distance = [self.bestEffortAtLocation distanceFromLocation:lastUpdateDoneAtLocation];
	}
	
	if (!lastUpdateDoneAtLocation || distance>100.0f ) {
		//invoca aggiornamento punti
		
		if (!isUpdatingContent) {
			isUpdatingContent = YES;
			[self updateContent];
		}
		
	}
	
	
    
}


- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
	NSLog(@"Error getting location");
    [cc3Layer.labelSprite setString:@"Sorry: error getting location."];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading
{
	self.lastHeading = [newHeading copy];
	
    // FARE UPDATE CONTENUTI
	//[arOverlay setCurHeading:self.lastHeading];
	//[arOverlay updateDrawing];
    
    [cc3Layer setCurHeading:self.lastHeading];
    [cc3Layer updateDrawing];
    
    [cc3Layer.radar updateHeading:self.lastHeading.trueHeading ];
	
	
}

- (BOOL)locationManagerShouldDisplayHeadingCalibration:(CLLocationManager *)manager
{
	return YES;
}









-(void) updateContent
{
    
    [cc3Layer.labelSprite setString:@"updating content."];

	if(loadingView!=nil){
		[loadingView release];
		loadingView = nil;
	}
	
	CGRect scrsize = [[UIScreen mainScreen] applicationFrame];
	
	loadingView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
	[loadingView setCenter:CGPointMake(scrsize.size.width/2.0, scrsize.size.height/2.0)]; // I do this because I'm in landscape mode
	
    [viewController.view  addSubview:loadingView]; // spinner is not visible until started
    //[visionVC.view  addSubview:loadingView]; // spinner is not visible until started
	[loadingView startAnimating];
	
	NSLog(@"%@/wp-content/plugins/neoreality/getARPoints.php?lat=%f&lon=%f", kHOSTBaseName, bestEffortAtLocation.coordinate.latitude, bestEffortAtLocation.coordinate.longitude);
    
	NSURL *url = [NSURL URLWithString: [NSString stringWithFormat: @"%@/wp-content/plugins/neoreality/getARPoints.php?lat=%f&lon=%f", kHOSTBaseName, bestEffortAtLocation.coordinate.latitude, bestEffortAtLocation.coordinate.longitude ]];
	ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    [request setCachePolicy:ASIFallbackToCacheIfLoadFailsCachePolicy];
    request.shouldAttemptPersistentConnection = NO;
    [request setTimeOutSeconds:30];
	[request setDelegate:self];
	[request startAsynchronous];
	
}





- (void)requestFinished:(ASIHTTPRequest *)request
{
	// Use when fetching text data
    // QUESTO E' IL CONTENTO RESTITUITO
	NSString *responseString = [[request responseString] copy];
	
	//NSLog(@"Received Response:\n\n%@", responseString);
	
	
    // QUESTO E' IL CONTENTO RESTITUITO
	NSArray *rd = (NSArray *) [responseString JSONValue];
	
	
    // FARE UPDATE CONTENUTI
	//[arOverlay loadUpdatedElements:rd];
	//[listVC loadUpdatedElements:rd];
	[cc3Layer loadUpdatedElements:rd];
    
    
	lastUpdateDoneAtLocation = [bestEffortAtLocation copy];
	
	//[rd release];
	
	isUpdatingContent = NO;
	[loadingView stopAnimating];
	[loadingView removeFromSuperview];
    [cc3Layer.labelSprite setString:@"content updated."];
	
}






- (void)requestFailed:(ASIHTTPRequest *)request
{
	isUpdatingContent = NO;
    
	[loadingView stopAnimating];
	[loadingView removeFromSuperview]; 
    
	NSError *error = [request error];
	NSLog(@"Received Error:\n\n%@", error);
    [cc3Layer.labelSprite setString:@"Sorry: network error, try again."];
    
}



@end
