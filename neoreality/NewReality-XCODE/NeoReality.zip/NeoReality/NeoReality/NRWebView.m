//
//  NRWebView.m
//  NeoReality
//
//  Created by salvatore iaconesi on 8/7/11.
//  Copyright 2011 AOS. All rights reserved.
//

#import "NRWebView.h"


@implementation NRWebView


@synthesize exitButton,webViewport;



-(void)doExitButton:(id)sender {
    
    
    [UIView beginAnimations:@"curldown" context:nil];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:1];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.superview cache:YES]; 
    [self removeFromSuperview];
    [UIView commitAnimations];
    
    
}

-(id) initWithFrame:(CGRect) frame
{
    
    self = [super initWithFrame:frame];
    if (self) {
     
        
        [self setUserInteractionEnabled: YES];
        
        exitButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, 40)];
        exitButton.backgroundColor = [UIColor blackColor];
        [exitButton setTag:1];
        exitButton.titleLabel.font = [UIFont systemFontOfSize:18];
        [exitButton setTitle:@"go back" forState:UIControlStateNormal];
        [exitButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [exitButton setUserInteractionEnabled:YES];
        
        [exitButton addTarget:self action:@selector(doExitButton:) forControlEvents:UIControlEventTouchUpInside ];
        
        [self addSubview:exitButton];
        
        webViewport = [[UIWebView alloc] initWithFrame:CGRectMake(0, 40, frame.size.width, frame.size.height- 40)];
        [webViewport setAllowsInlineMediaPlayback:YES];
        [webViewport setBackgroundColor:[UIColor whiteColor]];
        [webViewport setScalesPageToFit:YES];
        [webViewport setUserInteractionEnabled:YES];
        
        [self addSubview: webViewport];
        
        
    }
    
    return self;

}


-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    NSLog(@"touch sensed");
    
}



-(void) loadRequest: (NSURLRequest *) request{

    [webViewport loadRequest:request];
    
}


-(void) dealloc
{
    [exitButton release];
    [webViewport release];
    [super dealloc];
}

@end
