//
//  NRCCNodeController.m
//  NeoReality
//
//  Created by salvatore iaconesi on 8/7/11.
//  Copyright 2011 AOS. All rights reserved.
//

#import "NRCCNodeController.h"


@implementation NRCCNodeController




-(void)runScene:(CCScene*)scene onNode:(CCNode<ControlledCCNodeProtocol>*)aNode
{
	self.controlledNode = aNode;
	CCDirector* dir = [CCDirector sharedDirector];
	if(dir.runningScene) {
		[dir replaceScene: scene];
	} else {
		[dir runWithScene: scene];
	}
}





/*
-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
 
    NSLog(@"touch sensed");
    
    NSArray *sviews = [self.view subviews]; 
    
    for(int i=0; i<[sviews count]; i++){
    
        if( [[sviews objectAtIndex:i] isMemberOfClass:[NRWebView class] ]  ){
            
            NRWebView *tmp = (NRWebView *) [sviews objectAtIndex:i];
            [tmp touchesBegan:(NSSet *)touches withEvent: (UIEvent *)event];
            
        }
    
    }
    
    [super touchesBegan:(NSSet *)touches withEvent: (UIEvent *)event];
    
    
}
*/
@end
