//
//  NRWebView.h
//  NeoReality
//
//  Created by salvatore iaconesi on 8/7/11.
//  Copyright 2011 AOS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface NRWebView : UIView {
    
    
    UIButton *exitButton;
    UIWebView *webViewport;
    
}

@property (nonatomic,retain) UIButton *exitButton;
@property (nonatomic,retain) UIWebView *webViewport;

-(void) loadRequest: (NSURLRequest *) request;

@end
